$ApplicationName = "Install - Microsoft Visual C++ 2012 Update 4 - x64"
$CommandLine = "vcredist_x64.exe /Q"
$ApplicationSourcePath = "C:\Installers\Install - Microsoft Visual C++ 2012 Update 4 - x64"
Import-MDTApplication -Path "MDT:\Applications\Microsoft" -Enable "True" -Name $ApplicationName -ShortName $ApplicationName -Commandline $Commandline -WorkingDirectory ".\Applications\$ApplicationName" -ApplicationSourcePath $ApplicationSourcePath -DestinationFolder $ApplicationName -verbose