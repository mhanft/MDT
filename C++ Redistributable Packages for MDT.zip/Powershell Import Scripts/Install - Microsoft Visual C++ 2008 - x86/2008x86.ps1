$ApplicationName = "Install - Microsoft Visual C++ 2008 - x86"
$CommandLine = "vcredist_x86.exe /Q"
$ApplicationSourcePath = "C:\Installers\Install - Microsoft Visual C++ 2008 - x86"
Import-MDTApplication -Path "MDT:\Applications\Microsoft" -Enable "True" -Name $ApplicationName -ShortName $ApplicationName -Commandline $Commandline -WorkingDirectory ".\Applications\$ApplicationName" -ApplicationSourcePath $ApplicationSourcePath -DestinationFolder $ApplicationName -verbose